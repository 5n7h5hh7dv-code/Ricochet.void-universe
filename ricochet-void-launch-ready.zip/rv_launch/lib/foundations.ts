export const hiddenProgression = [
  { slug: 'coded-mirror', title: 'The Coded Mirror', veil: 'The Fracture Veil', identity: 'Observer', fragment: 'OBSERVER' },
  { slug: 'void-protocol-7', title: 'Void Protocol 7', veil: 'The Silent Current', identity: 'Architect', fragment: 'ARCHITECT' },
  { slug: 'neural-wealth-mapping', title: 'Neural Wealth Mapping', veil: 'The Golden Circuit', identity: 'Circuit Architect', fragment: 'BUILDER' },
  { slug: 'dopamine-collapse-manual', title: 'The Dopamine Collapse Manual', veil: 'The Static Abyss', identity: 'Signal Keeper', fragment: 'STATIC' },
  { slug: 'project-ascension', title: 'Project Ascension', veil: 'The Elevation Engine', identity: 'Trajectory Forger', fragment: 'ELEVATION' },
  { slug: 'human-glitch', title: 'The Human Glitch', veil: 'The Error Threshold', identity: 'System Adapter', fragment: 'THRESHOLD' },
  { slug: 'psychological-warfare-against-yourself', title: 'Psychological Warfare Against Yourself', veil: 'The Shadow Conflict', identity: 'Internal Resistance Analyst', fragment: 'SHADOW' },
  { slug: 'internal-empire-blueprint', title: 'The Internal Empire Blueprint', veil: 'The Sovereign Frame', identity: 'Sovereign Architect', fragment: 'ENTRY' }
] as const;

export const publicArchiveDisplay = [...hiddenProgression]
  .map(({ slug, title, veil }) => ({ slug, title, veil }))
  .sort((a,b)=> a.title.localeCompare(b.title));

export const entryTransmission = 'OBSERVE BUILD PROTECT ADAPT CREATE';
