export const tiers = [
 {key:'entry', name:'Entry Access', price:'$0', note:'Earned after foundation completion.'},
 {key:'signal', name:'Signal Access', price:'$9.99/month', note:'Expanded systems, signal chambers, and deeper archive releases.'},
 {key:'sub_creator', name:'Sub-Creator Access', price:'$24.99/month', note:'Creator paths, contribution systems, and early builder tools.'},
 {key:'architect', name:'Architect Circle', price:'$49.99/month', note:'Advanced chambers, moderation pathways, and system-building access.'},
 {key:'universe_architect', name:'Universe Architect', price:'$99.99/month', note:'Highest public access layer for expansion architects.'}
] as const;
