const base = process.env.NODE_ENV === 'production' ? 'https://api-m.paypal.com' : 'https://api-m.sandbox.paypal.com';
export async function paypalAccessToken(){
 const id=process.env.PAYPAL_CLIENT_ID, secret=process.env.PAYPAL_CLIENT_SECRET;
 if(!id||!secret) throw new Error('Missing PayPal credentials');
 const r=await fetch(`${base}/v1/oauth2/token`,{method:'POST',headers:{Authorization:`Basic ${Buffer.from(`${id}:${secret}`).toString('base64')}`,'Content-Type':'application/x-www-form-urlencoded'},body:'grant_type=client_credentials'});
 if(!r.ok) throw new Error(await r.text());
 return (await r.json()).access_token as string;
}
export function planForTier(tier:string){
 const map:Record<string,string|undefined>={signal:process.env.PAYPAL_PLAN_SIGNAL_ACCESS,sub_creator:process.env.PAYPAL_PLAN_SUB_CREATOR,architect:process.env.PAYPAL_PLAN_ARCHITECT_CIRCLE,universe_architect:process.env.PAYPAL_PLAN_UNIVERSE_ARCHITECT};
 return map[tier];
}
export { base as paypalBase };
