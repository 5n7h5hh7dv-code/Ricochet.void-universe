create table if not exists profiles (
  id uuid primary key default gen_random_uuid(),
  email text unique not null,
  entry_unlocked boolean default false,
  access_tier text default 'none',
  paypal_subscription_id text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create table if not exists archive_submissions (
  id uuid primary key default gen_random_uuid(),
  email text not null,
  phrase text not null,
  accepted boolean default false,
  created_at timestamptz default now()
);
create table if not exists content_items (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  required_tier text default 'entry',
  file_path text,
  is_published boolean default false,
  created_at timestamptz default now()
);
