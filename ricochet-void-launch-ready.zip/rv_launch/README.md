# 1RicochetVoidUniverse Launch Package

This is the unified cinematic + platform codebase for the Ricochet Void Universe.

## What is included
- Cinematic public entrance
- Foundation Archives page with archive names shown without numbering
- Hidden progression order kept in `lib/foundations.ts`
- Foundation answer submission / Entry Access unlock
- PayPal subscription flow placeholders
- Supabase schema for profiles, submissions, and content
- Member dashboard structure
- Future Gear section
- Hidden far-off Creator Vault route
- Blank Creator Vault credentials in `.env.example`

## Private values you must fill in
Copy `.env.example` to `.env.local` and fill:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`
- `CREATOR_VAULT_NAME`
- `CREATOR_VAULT_PASSWORD`
- `PAYPAL_CLIENT_ID`
- `PAYPAL_CLIENT_SECRET`
- PayPal plan IDs for each paid tier

## PDFs
Place final PDF files in `public/foundations/` using these filenames:
- coded-mirror.pdf
- void-protocol-7.pdf
- neural-wealth-mapping.pdf
- dopamine-collapse-manual.pdf
- project-ascension.pdf
- human-glitch.pdf
- psychological-warfare-against-yourself.pdf
- internal-empire-blueprint.pdf

The live site displays archive names without public numbers.

## Entry unlock phrase
Default placeholder from the recovered Signal Phase:
`OBSERVE BUILD PROTECT ADAPT CREATE`

You can change it in `.env.local` with `ENTRY_UNLOCK_PHRASE=`.

## Launch steps
1. Install Node.js.
2. Run `npm install`.
3. Create Supabase project and run `supabase/schema.sql` in SQL editor.
4. Create PayPal app and subscription plans.
5. Fill `.env.local`.
6. Add final PDFs to `public/foundations/`.
7. Run `npm run dev` locally.
8. Deploy to Vercel and connect domain `1RicochetVoidUniverse.com`.

## Important
PayPal webhook signature verification should be enabled before real payments. This starter includes the webhook receiver and database update logic, but you must connect the webhook ID in PayPal and verify in production.
