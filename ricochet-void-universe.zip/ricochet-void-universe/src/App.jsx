import { Lock, Sparkles, Archive, Shield, ShoppingBag } from 'lucide-react'

const tiers = [
  ['Entry Access', '$0', 'Unlocked after foundation completion'],
  ['Signal Access', '$9.99/mo', 'Deeper chambers and monthly signal drops'],
  ['Sub-Creator Access', '$24.99/mo', 'Creator path tools and progression rooms'],
  ['Architect Circle', '$49.99/mo', 'Advanced archive access and community power'],
  ['Universe Architect', '$99.99/mo', 'Highest public tier for builders and visionaries'],
]

const archives = [
  'The Mirror Code',
  'Silence Architecture',
  'Signal Where Noise Falls',
  'The Ricochet Path',
  'The Void Foundation'
]

export default function App() {
  return (
    <main>
      <section className="hero">
        <div className="eyebrow">1RicochetVoidUniverse.com</div>
        <h1>Ricochet Void Universe</h1>
        <p>
          A locked cinematic universe built through foundation archives, hidden signals,
          self-development, mystery, progression, and future intelligent collaboration.
        </p>
        <div className="heroActions">
          <a href="#foundation">Begin Foundation Path</a>
          <a className="ghost" href="#access">View Access Tiers</a>
        </div>
      </section>

      <section id="foundation" className="panel">
        <h2><Archive size={26}/> Foundation Archives</h2>
        <p>
          Archive order is discovered through progression. Names are shown, but the true path
          is earned by attention, completion, and correct hidden answers.
        </p>
        <div className="grid">
          {archives.map((name) => (
            <div className="card" key={name}>
              <Lock size={20}/>
              <h3>{name}</h3>
              <p>Locked archive signal. Complete the foundation to reveal the next layer.</p>
            </div>
          ))}
        </div>
      </section>

      <section className="panel dark">
        <h2><Shield size={26}/> Entry Verification</h2>
        <p>
          Submit the completed hidden foundation answers here. This demo keeps the gate visual;
          connect this form later to your database, email automation, or payment/member system.
        </p>
        <form onSubmit={(e) => e.preventDefault()} className="gate">
          <input placeholder="Enter foundation answer sequence" />
          <button>Request Entry Access</button>
        </form>
      </section>

      <section id="access" className="panel">
        <h2><Sparkles size={26}/> Access Tiers</h2>
        <div className="pricing">
          {tiers.map(([name, price, desc]) => (
            <div className="priceCard" key={name}>
              <h3>{name}</h3>
              <strong>{price}</strong>
              <p>{desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="panel future">
        <h2><ShoppingBag size={26}/> Future Gear</h2>
        <p>
          Coming soon: physical drops, symbolic tools, creator items, archive-linked gear,
          and universe expansion pieces.
        </p>
      </section>
    </main>
  )
}
